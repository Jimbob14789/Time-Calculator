def add_time(start, duration, day=''):

  daysPassed = 0
  dayLoc = -1
  x = 0

  #list of the days of the week is made
  days=["sunday","monday","tuesday","wednesday","thursday","friday","saturday"]

  #day input is made all lowercase
  day = day.lower()

  #finds the location of days input, index() method not used because '' is not in list
  for i in days:
    if days[x] == day:
      dayLoc = x
    x+=1

  #replaces spaces with : to make splitting easier
  startReplace = start.replace(" ",":")

  #starting time is split
  startSplit = startReplace.split(":")

  startHours = int(startSplit[0])
  startMin = int(startSplit[1])

  #duration is split
  durSplit = duration.split(":")

  durHours = int(durSplit[0])
  durMin = int(durSplit[1])

  amPm = startSplit[2]

  #converts 12 hour time to 24 hour time for easier math
  if amPm == "PM" and startHours != "12":
    startHours += 12

  newMin = durMin + startMin
  newHours = durHours + startHours

  newMin = durMin + startMin

  #checks if the minutes will add to a new hour. Will still work with minutes adding to multiple hours
  if newMin >= 60:
    newHours += newMin/60
    newMin = newMin%60

  #determines how many days passed based on hours
  if newHours >= 24:
    daysPassed = newHours/24
    daysPassed = int(daysPassed)
    newHours = newHours%24
    newHours = int(newHours)

  #used to truncate newHours
  newHours = int(newHours)

  #determines am or pm
  if newHours >= 12:
    amPm = "PM"

  else:
    amPm = "AM"

  #in 24 hour time midnight is 0 so 0 will have to be 12 for 12 hour time
  if newHours == 0:
    newHours = 12

  #converts 24 hour to 12 hour
  if newHours>12:
    newHours-=12

  #exsures a leading 0 in the minutes place
  if newMin < 10:
    newMin = "0"+str(newMin)

  #finds the new day of the week if a day of the week was entered
  if dayLoc != -1:
    newDay = dayLoc+daysPassed
    day = days[newDay%7]

  #capitalizes the day
  day = day.capitalize()
  
  if day != '':
    day = ", "+day
  
  newTime = str(newHours)+":"+str(newMin)+" "+amPm+day
  
  if daysPassed > 1:
    daysPhrase = " ("+str(daysPassed)+" days later)"
    newTime += daysPhrase
  
  elif daysPassed ==1:
    daysPhrase = " (next day)"
    newTime += daysPhrase
    
  return newTime